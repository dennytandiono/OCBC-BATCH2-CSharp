using finalproject.Configuration;

namespace finalproject.Models.DTOs.Responses
{
    public class RegistrationResponse: AuthResult{
        
    }
}