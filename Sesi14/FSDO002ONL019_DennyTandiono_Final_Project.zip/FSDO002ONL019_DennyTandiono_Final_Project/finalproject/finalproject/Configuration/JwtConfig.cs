using System;

namespace finalproject.Configuration
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}