-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 01, 2021 at 10:49 AM
-- Server version: 8.0.27
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paymentdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `AspNetRoleClaims`
--

CREATE TABLE `AspNetRoleClaims` (
  `Id` int NOT NULL,
  `RoleId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ClaimType` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ClaimValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetRoles`
--

CREATE TABLE `AspNetRoles` (
  `Id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserClaims`
--

CREATE TABLE `AspNetUserClaims` (
  `Id` int NOT NULL,
  `UserId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ClaimType` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ClaimValue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserLogins`
--

CREATE TABLE `AspNetUserLogins` (
  `LoginProvider` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProviderKey` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProviderDisplayName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `UserId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserRoles`
--

CREATE TABLE `AspNetUserRoles` (
  `UserId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `RoleId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUsers`
--

CREATE TABLE `AspNetUsers` (
  `Id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedUserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedEmail` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `SecurityStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumber` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `AspNetUsers`
--

INSERT INTO `AspNetUsers` (`Id`, `UserName`, `NormalizedUserName`, `Email`, `NormalizedEmail`, `EmailConfirmed`, `PasswordHash`, `SecurityStamp`, `ConcurrencyStamp`, `PhoneNumber`, `PhoneNumberConfirmed`, `TwoFactorEnabled`, `LockoutEnd`, `LockoutEnabled`, `AccessFailedCount`) VALUES
('4372180b-8d48-4ee6-87ce-51dd0e6daf02', 'den', 'DEN', 'den@gmail.com', 'DEN@GMAIL.COM', 0, 'AQAAAAEAACcQAAAAEFyrUHFIDny0gTw2YA1cSd+xRYVE64jPLTjSegpKR5CQ8VXIb+KyvYgErM69B6Wsmw==', 'HXKSAVVLWAERP2H4H65IIUH3FRUJ4LVM', '846f57e7-d955-449f-833b-d3e6b512d11b', NULL, 0, 0, NULL, 1, 0),
('90f61933-aaba-4553-b0e2-1c2af6244410', 'Halo', 'HALO', 'halo@gmail.com', 'HALO@GMAIL.COM', 0, 'AQAAAAEAACcQAAAAEN/LZDYZcFL2q9vbjFUXhJ8knE7czum88MfiWuvHhy7pI0qnID0GO5geE/A1oKqh9g==', 'X6EX6F5Q7E7GGCT37QIVKLO6MYGCTIFJ', 'da9bcd8f-ede5-4df2-8642-8a3d815a8590', NULL, 0, 0, NULL, 1, 0),
('ec4c2e1e-1a33-400c-8449-3503c71c7d07', 'test', 'TEST', 'test@gmail.com', 'TEST@GMAIL.COM', 0, 'AQAAAAEAACcQAAAAECx45Z+qS6SIYEwwzGkaY68DXUAiLana5Eb7q2hsM7rCIxWhejNA7pfadI1SU6lvCw==', 'R7SCCXB5AALLMSKEO34S44WQ2GM7PSHR', 'c2b926ac-0d8f-4659-bb0f-b4cce144c7da', NULL, 0, 0, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserTokens`
--

CREATE TABLE `AspNetUserTokens` (
  `UserId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LoginProvider` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Items`
--

CREATE TABLE `Items` (
  `Id` int NOT NULL,
  `cardOwnerName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `cardNumber` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `expirationDate` datetime(6) DEFAULT NULL,
  `securityCode` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Items`
--

INSERT INTO `Items` (`Id`, `cardOwnerName`, `cardNumber`, `expirationDate`, `securityCode`) VALUES
(1, 'Denny', '18937189', '2022-12-02 00:00:00.000000', 'ASDF123'),
(2, 'Karen', '1318291', '2021-10-10 00:00:00.000000', 'KRN787');

-- --------------------------------------------------------

--
-- Table structure for table `RefreshTokens`
--

CREATE TABLE `RefreshTokens` (
  `Id` int NOT NULL,
  `UserId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `JwtId` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `IsUsed` tinyint(1) NOT NULL,
  `IsRevorked` tinyint(1) NOT NULL,
  `AddedDate` datetime(6) NOT NULL,
  `ExpiryDate` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `RefreshTokens`
--

INSERT INTO `RefreshTokens` (`Id`, `UserId`, `Token`, `JwtId`, `IsUsed`, `IsRevorked`, `AddedDate`, `ExpiryDate`) VALUES
(1, '4372180b-8d48-4ee6-87ce-51dd0e6daf02', 'RBPBZ5WFATDCAHYIU3AKOFTXDYOXBTJP6U3f7f88b72-b961-485c-8bc7-b3f26771c026', '18bf760e-2e89-4183-8979-6b2a1670048d', 0, 0, '2021-12-01 06:27:04.170667', '2022-01-01 06:27:04.170699'),
(2, '4372180b-8d48-4ee6-87ce-51dd0e6daf02', 'RDH3WHGAKVD1PRNJJUGBVBHRMSZUKXK27026c488ed0-7c22-4d09-9732-0390aaa500e0', 'd76f936c-c788-4e9b-a374-1074e44bde85', 0, 0, '2021-12-01 06:30:16.377277', '2022-01-01 06:30:16.377278'),
(3, '4372180b-8d48-4ee6-87ce-51dd0e6daf02', 'CQV4X3KSZEEI5ETPJQ6D8X5YN2USNWMZFCVdfd19742-e750-4163-98a1-2d61d1222cd8', '8d19a6ce-e24f-4047-88da-6734126e3620', 0, 0, '2021-12-01 06:31:01.836563', '2022-01-01 06:31:01.836601'),
(4, '4372180b-8d48-4ee6-87ce-51dd0e6daf02', 'NZ4X2SJN8LYGF3AYZDRRQD6MH8DOXN5OTZ2ff0293ca-ed6f-4ea3-8494-7ffac50adb0e', '94eadaff-2669-494a-8d79-5e82e66f041f', 0, 0, '2021-12-01 06:45:25.403180', '2022-01-01 06:45:25.403200'),
(5, 'ec4c2e1e-1a33-400c-8449-3503c71c7d07', 'OCVBA3IX3Q4O8QKHFU6LEQXSSKBZLQUPCVI2a4c1f5c-d7e7-4f88-a218-861453e42953', 'c2deba2e-4f08-435e-bfef-49d40300a1d7', 0, 0, '2021-12-01 06:46:44.536358', '2022-01-01 06:46:44.536358'),
(6, '90f61933-aaba-4553-b0e2-1c2af6244410', '7NTZ2UTQYMTUNT96K2I30TIH86C46I52V6R965bd88a-4647-4514-ba57-4178aa3c4fc0', '35243aa8-ecb2-4e72-9f9b-8dfc0840a4af', 0, 0, '2021-12-01 08:03:10.737983', '2022-01-01 08:03:10.738014'),
(7, '90f61933-aaba-4553-b0e2-1c2af6244410', 'N0X7ULPN9ANTUIA6XEXTLOWNH74235GHRYR34d5eb71-22c3-4bcd-a287-297d845403ef', 'd308fe6d-6747-4274-a1c2-5c80d32b1c25', 0, 0, '2021-12-01 08:06:20.846834', '2022-01-01 08:06:20.846834'),
(8, '90f61933-aaba-4553-b0e2-1c2af6244410', '74DS449Q8ON3DK5M8AALFMADFBI2GWPUV3Rd38da43a-7d85-497a-9919-368085dad034', '8fbe4d31-ddb3-4870-8c5b-d265f2e7121e', 0, 0, '2021-12-01 08:11:05.375362', '2022-01-01 08:11:05.375362'),
(9, '90f61933-aaba-4553-b0e2-1c2af6244410', 'PAJH2AI9OJ3AAPY90AX4MRKDL5BXYOBHTZFce97a9ce-dcd6-4c82-bf8f-87a161701662', 'e2c735df-a972-4c80-9691-df587920c963', 0, 0, '2021-12-01 08:21:53.971740', '2022-01-01 08:21:53.971740'),
(10, '90f61933-aaba-4553-b0e2-1c2af6244410', 'D4025Y9OZ43MEKFNE8A2X19PWGKIYRC7CC5210aa579-0543-46bf-8010-b728d7f94555', '5c0e5fbf-c269-41e7-9e62-f6ef7d4a36c5', 0, 0, '2021-12-01 08:28:07.802408', '2022-01-01 08:28:07.802408'),
(11, '90f61933-aaba-4553-b0e2-1c2af6244410', 'CYVAKHGRL8N97J0THZVJRWSGHX5P81C5AXAe647920a-2b4d-4438-a321-1f83e0bc6b9c', '0ccb7db2-e397-42ee-9289-c7b093efb1c6', 0, 0, '2021-12-01 08:32:51.708091', '2022-01-01 08:32:51.708092'),
(12, '90f61933-aaba-4553-b0e2-1c2af6244410', 'CUFCK591MQZ57QOKRKHQURO6PJS5WAGXHQA927fcee5-e208-4c7d-bc9f-9e9e872beb07', '4e28f883-8d33-49b1-a302-8ac82ce41732', 0, 0, '2021-12-01 08:50:32.237446', '2021-12-01 08:51:32.237474'),
(13, '90f61933-aaba-4553-b0e2-1c2af6244410', 'RMVBNB8RUK0XECTPM5GG0ISBQLKLA0OOLAFd8e958c6-5c41-4283-9b5c-223d66d588a5', 'fbb1b475-dd9e-4ed1-bd32-12d965d6d189', 0, 0, '2021-12-01 09:18:13.535572', '2021-12-01 09:19:13.535572'),
(14, '90f61933-aaba-4553-b0e2-1c2af6244410', 'GHHI36J5X0GIZY50SVX1454OCPUY40CAV814a337a5e-63f0-4f33-ae4e-d3b5af1695b4', '161ef441-2292-4301-b9f4-b78781fc6da9', 0, 0, '2021-12-01 09:18:31.696206', '2021-12-01 09:19:31.696206');

-- --------------------------------------------------------

--
-- Table structure for table `__EFMigrationsHistory`
--

CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `__EFMigrationsHistory`
--

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`) VALUES
('20211201042354_db online', '5.0.11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_AspNetRoleClaims_RoleId` (`RoleId`);

--
-- Indexes for table `AspNetRoles`
--
ALTER TABLE `AspNetRoles`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `RoleNameIndex` (`NormalizedName`);

--
-- Indexes for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_AspNetUserClaims_UserId` (`UserId`);

--
-- Indexes for table `AspNetUserLogins`
--
ALTER TABLE `AspNetUserLogins`
  ADD PRIMARY KEY (`LoginProvider`,`ProviderKey`),
  ADD KEY `IX_AspNetUserLogins_UserId` (`UserId`);

--
-- Indexes for table `AspNetUserRoles`
--
ALTER TABLE `AspNetUserRoles`
  ADD PRIMARY KEY (`UserId`,`RoleId`),
  ADD KEY `IX_AspNetUserRoles_RoleId` (`RoleId`);

--
-- Indexes for table `AspNetUsers`
--
ALTER TABLE `AspNetUsers`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `UserNameIndex` (`NormalizedUserName`),
  ADD KEY `EmailIndex` (`NormalizedEmail`);

--
-- Indexes for table `AspNetUserTokens`
--
ALTER TABLE `AspNetUserTokens`
  ADD PRIMARY KEY (`UserId`,`LoginProvider`,`Name`);

--
-- Indexes for table `Items`
--
ALTER TABLE `Items`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `RefreshTokens`
--
ALTER TABLE `RefreshTokens`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_RefreshTokens_UserId` (`UserId`);

--
-- Indexes for table `__EFMigrationsHistory`
--
ALTER TABLE `__EFMigrationsHistory`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Items`
--
ALTER TABLE `Items`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `RefreshTokens`
--
ALTER TABLE `RefreshTokens`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  ADD CONSTRAINT `FK_AspNetRoleClaims_AspNetRoles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  ADD CONSTRAINT `FK_AspNetUserClaims_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserLogins`
--
ALTER TABLE `AspNetUserLogins`
  ADD CONSTRAINT `FK_AspNetUserLogins_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserRoles`
--
ALTER TABLE `AspNetUserRoles`
  ADD CONSTRAINT `FK_AspNetUserRoles_AspNetRoles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_AspNetUserRoles_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserTokens`
--
ALTER TABLE `AspNetUserTokens`
  ADD CONSTRAINT `FK_AspNetUserTokens_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `RefreshTokens`
--
ALTER TABLE `RefreshTokens`
  ADD CONSTRAINT `FK_RefreshTokens_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
